"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var SzamhalmazokComponent = (function (_super) {
    __extends(SzamhalmazokComponent, _super);
    function SzamhalmazokComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    SzamhalmazokComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'statisztika',
            templateUrl: './szamhalmazok.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], SzamhalmazokComponent);
    return SzamhalmazokComponent;
}(tema_component_1.TemaComponent));
exports.SzamhalmazokComponent = SzamhalmazokComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3phbWhhbG1hem9rLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInN6YW1oYWxtYXpvay5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsMENBQXlDO0FBQ3pDLDBDQUEyQztBQUMzQyxnQ0FBK0I7QUFFL0IsdURBQXFEO0FBT3JEO0lBQTJDLHlDQUFhO0lBQ3RELCtCQUNVLE1BQWMsRUFDZCxRQUFrQixFQUNsQixJQUFVO1FBSHBCLFlBS0Usa0JBQU0sTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FDOUI7UUFMUyxZQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsY0FBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixVQUFJLEdBQUosSUFBSSxDQUFNOztJQUdwQixDQUFDO0lBUFUscUJBQXFCO1FBTGpDLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLGFBQWE7WUFDdkIsV0FBVyxFQUFFLCtCQUErQjtTQUM3QyxDQUFDO3lDQUdrQixlQUFNO1lBQ0osaUJBQVE7WUFDWixXQUFJO09BSlQscUJBQXFCLENBUWpDO0lBQUQsNEJBQUM7Q0FBQSxBQVJELENBQTJDLDhCQUFhLEdBUXZEO0FBUlksc0RBQXFCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5cbmltcG9ydCB7IFRlbWFDb21wb25lbnQgfSBmcm9tICcuLi8uLi90ZW1hLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogJ3N0YXRpc3p0aWthJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3N6YW1oYWxtYXpvay5jb21wb25lbnQuaHRtbCdcbn0pXG5leHBvcnQgY2xhc3MgU3phbWhhbG1hem9rQ29tcG9uZW50IGV4dGVuZHMgVGVtYUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkge1xuICAgIHN1cGVyKHJvdXRlciwgbG9jYXRpb24sIHBhZ2UpO1xuICB9XG59XG4iXX0=