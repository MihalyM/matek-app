"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var application_settings_1 = require("application-settings");
var TemaComponent = (function () {
    function TemaComponent(router, location, page) {
        this.temakor = [];
        this.tema = {};
        this.r = router;
        this.l = location;
        this.p = page;
        var dataJson = application_settings_1.getString("dataJson");
        var temakorok = JSON.parse(dataJson).temakorok;
        var currentUrl = router.url;
        // Talajuk meg a temakort eloszor
        for (var _i = 0, temakorok_1 = temakorok; _i < temakorok_1.length; _i++) {
            var temakor = temakorok_1[_i];
            if (currentUrl.indexOf(temakor.url) > -1) {
                this.temakor = temakor;
                break;
            }
        }
        // majd talaljuk meg a temat a temakoron belul, ha vannak temak
        if (this.temakor.temak) {
            for (var _a = 0, _b = this.temakor.temak; _a < _b.length; _a++) {
                var tema = _b[_a];
                if (tema.url === currentUrl) {
                    this.tema = tema;
                    console.log(JSON.stringify(tema));
                    break;
                }
            }
        }
        else {
            // Elofordulhat, hogy nincs meg a keresett tema
            this.tema.title = 'Not found';
        }
    }
    TemaComponent.prototype.goBack = function () {
        this.p.actionBarHidden = true;
        this.l.back();
    };
    return TemaComponent;
}());
exports.TemaComponent = TemaComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtYS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0ZW1hLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDZEQUE0RDtBQUU1RDtJQU9FLHVCQUNFLE1BQU0sRUFDTixRQUFRLEVBQ1IsSUFBSTtRQVROLFlBQU8sR0FBUSxFQUFFLENBQUM7UUFDbEIsU0FBSSxHQUFRLEVBQUUsQ0FBQztRQVViLElBQUksQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBRWQsSUFBTSxRQUFRLEdBQUcsZ0NBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2QyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUNqRCxJQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQzlCLGlDQUFpQztRQUNqQyxHQUFHLENBQUMsQ0FBa0IsVUFBUyxFQUFULHVCQUFTLEVBQVQsdUJBQVMsRUFBVCxJQUFTO1lBQTFCLElBQU0sT0FBTyxrQkFBQTtZQUNoQixFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUN2QixLQUFLLENBQUM7WUFDUixDQUFDO1NBQ0Y7UUFDRCwrREFBK0Q7UUFDL0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLEdBQUcsQ0FBQyxDQUFlLFVBQWtCLEVBQWxCLEtBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQWxCLGNBQWtCLEVBQWxCLElBQWtCO2dCQUFoQyxJQUFNLElBQUksU0FBQTtnQkFDYixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBQzVCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDbEMsS0FBSyxDQUFDO2dCQUNSLENBQUM7YUFDRjtRQUNILENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNOLCtDQUErQztZQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUM7UUFDaEMsQ0FBQztJQUNILENBQUM7SUFFRCw4QkFBTSxHQUFOO1FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzlCLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDaEIsQ0FBQztJQUNILG9CQUFDO0FBQUQsQ0FBQyxBQTdDRCxJQTZDQztBQTdDWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNldFN0cmluZywgZ2V0U3RyaW5nIH0gZnJvbSBcImFwcGxpY2F0aW9uLXNldHRpbmdzXCI7XG5cbmV4cG9ydCBjbGFzcyBUZW1hQ29tcG9uZW50IHtcbiAgdGVtYWtvcjogYW55ID0gW107XG4gIHRlbWE6IGFueSA9IHt9O1xuICByO1xuICBsO1xuICBwO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHJvdXRlcixcbiAgICBsb2NhdGlvbixcbiAgICBwYWdlXG4gICkge1xuICAgIHRoaXMuciA9IHJvdXRlcjtcbiAgICB0aGlzLmwgPSBsb2NhdGlvbjtcbiAgICB0aGlzLnAgPSBwYWdlO1xuXG4gICAgY29uc3QgZGF0YUpzb24gPSBnZXRTdHJpbmcoXCJkYXRhSnNvblwiKTtcbiAgICBjb25zdCB0ZW1ha29yb2sgPSBKU09OLnBhcnNlKGRhdGFKc29uKS50ZW1ha29yb2s7XG4gICAgY29uc3QgY3VycmVudFVybCA9IHJvdXRlci51cmw7XG4gICAgLy8gVGFsYWp1ayBtZWcgYSB0ZW1ha29ydCBlbG9zem9yXG4gICAgZm9yIChjb25zdCB0ZW1ha29yIG9mIHRlbWFrb3Jvaykge1xuICAgICAgaWYgKGN1cnJlbnRVcmwuaW5kZXhPZih0ZW1ha29yLnVybCkgPiAtMSkge1xuICAgICAgICB0aGlzLnRlbWFrb3IgPSB0ZW1ha29yO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gbWFqZCB0YWxhbGp1ayBtZWcgYSB0ZW1hdCBhIHRlbWFrb3JvbiBiZWx1bCwgaGEgdmFubmFrIHRlbWFrXG4gICAgaWYgKHRoaXMudGVtYWtvci50ZW1haykge1xuICAgICAgZm9yIChjb25zdCB0ZW1hIG9mIHRoaXMudGVtYWtvci50ZW1haykge1xuICAgICAgICBpZiAodGVtYS51cmwgPT09IGN1cnJlbnRVcmwpIHtcbiAgICAgICAgICB0aGlzLnRlbWEgPSB0ZW1hO1xuICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHRlbWEpKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBFbG9mb3JkdWxoYXQsIGhvZ3kgbmluY3MgbWVnIGEga2VyZXNldHQgdGVtYVxuICAgICAgdGhpcy50ZW1hLnRpdGxlID0gJ05vdCBmb3VuZCc7XG4gICAgfVxuICB9XG5cbiAgZ29CYWNrKCkge1xuICAgIHRoaXMucC5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xuICAgIHRoaXMubC5iYWNrKCk7XG4gIH1cbn1cbiJdfQ==