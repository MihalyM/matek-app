"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var MuveletekTermeszetesSzamokkalComponent = (function (_super) {
    __extends(MuveletekTermeszetesSzamokkalComponent, _super);
    function MuveletekTermeszetesSzamokkalComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    MuveletekTermeszetesSzamokkalComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'muveletek-termeszetes-szamokkal',
            templateUrl: './muveletek-termeszetes-szamokkal.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], MuveletekTermeszetesSzamokkalComponent);
    return MuveletekTermeszetesSzamokkalComponent;
}(tema_component_1.TemaComponent));
exports.MuveletekTermeszetesSzamokkalComponent = MuveletekTermeszetesSzamokkalComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXV2ZWxldGVrLXRlcm1lc3pldGVzLXN6YW1va2thbC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtdXZlbGV0ZWstdGVybWVzemV0ZXMtc3phbW9ra2FsLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBNEQsMERBQWE7SUFDdkUsZ0RBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSxzQ0FBc0M7UUFMbEQsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsaUNBQWlDO1lBQzNDLFdBQVcsRUFBRSxrREFBa0Q7U0FDaEUsQ0FBQzt5Q0FHa0IsZUFBTTtZQUNKLGlCQUFRO1lBQ1osV0FBSTtPQUpULHNDQUFzQyxDQVFsRDtJQUFELDZDQUFDO0NBQUEsQUFSRCxDQUE0RCw4QkFBYSxHQVF4RTtBQVJZLHdGQUFzQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xuXG5pbXBvcnQgeyBUZW1hQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vdGVtYS5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgc2VsZWN0b3I6ICdtdXZlbGV0ZWstdGVybWVzemV0ZXMtc3phbW9ra2FsJyxcbiAgdGVtcGxhdGVVcmw6ICcuL211dmVsZXRlay10ZXJtZXN6ZXRlcy1zemFtb2trYWwuY29tcG9uZW50Lmh0bWwnXG59KVxuZXhwb3J0IGNsYXNzIE11dmVsZXRla1Rlcm1lc3pldGVzU3phbW9ra2FsQ29tcG9uZW50IGV4dGVuZHMgVGVtYUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkge1xuICAgIHN1cGVyKHJvdXRlciwgbG9jYXRpb24sIHBhZ2UpO1xuICB9XG59XG4iXX0=