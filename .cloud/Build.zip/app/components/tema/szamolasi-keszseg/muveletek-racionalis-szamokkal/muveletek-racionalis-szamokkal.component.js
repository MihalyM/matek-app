"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var MuveletekRacionalisSzamokkalComponent = (function (_super) {
    __extends(MuveletekRacionalisSzamokkalComponent, _super);
    function MuveletekRacionalisSzamokkalComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    MuveletekRacionalisSzamokkalComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'muveletek-racionalis-szamokkal',
            templateUrl: './muveletek-racionalis-szamokkal.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], MuveletekRacionalisSzamokkalComponent);
    return MuveletekRacionalisSzamokkalComponent;
}(tema_component_1.TemaComponent));
exports.MuveletekRacionalisSzamokkalComponent = MuveletekRacionalisSzamokkalComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXV2ZWxldGVrLXJhY2lvbmFsaXMtc3phbW9ra2FsLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm11dmVsZXRlay1yYWNpb25hbGlzLXN6YW1va2thbC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsMENBQXlDO0FBQ3pDLDBDQUEyQztBQUMzQyxnQ0FBK0I7QUFFL0IsdURBQXFEO0FBT3JEO0lBQTJELHlEQUFhO0lBQ3RFLCtDQUNVLE1BQWMsRUFDZCxRQUFrQixFQUNsQixJQUFVO1FBSHBCLFlBS0Usa0JBQU0sTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FDOUI7UUFMUyxZQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsY0FBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixVQUFJLEdBQUosSUFBSSxDQUFNOztJQUdwQixDQUFDO0lBUFUscUNBQXFDO1FBTGpELGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLGdDQUFnQztZQUMxQyxXQUFXLEVBQUUsaURBQWlEO1NBQy9ELENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCxxQ0FBcUMsQ0FRakQ7SUFBRCw0Q0FBQztDQUFBLEFBUkQsQ0FBMkQsOEJBQWEsR0FRdkU7QUFSWSxzRkFBcUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAnbXV2ZWxldGVrLXJhY2lvbmFsaXMtc3phbW9ra2FsJyxcbiAgdGVtcGxhdGVVcmw6ICcuL211dmVsZXRlay1yYWNpb25hbGlzLXN6YW1va2thbC5jb21wb25lbnQuaHRtbCdcbn0pXG5leHBvcnQgY2xhc3MgTXV2ZWxldGVrUmFjaW9uYWxpc1N6YW1va2thbENvbXBvbmVudCBleHRlbmRzIFRlbWFDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHtcbiAgICBzdXBlcihyb3V0ZXIsIGxvY2F0aW9uLCBwYWdlKTtcbiAgfVxufVxuIl19