"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Angular
var common_1 = require("@angular/common");
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var TemakorComponent = (function () {
    function TemakorComponent(router, location, page) {
        this.router = router;
        this.location = location;
        this.page = page;
        this.temakor = [];
    }
    TemakorComponent.prototype.ngOnInit = function () {
        var dataJson = application_settings_1.getString("dataJson");
        var temakorok = JSON.parse(dataJson).temakorok;
        for (var _i = 0, temakorok_1 = temakorok; _i < temakorok_1.length; _i++) {
            var temakor = temakorok_1[_i];
            if (temakor.url === this.router.url) {
                this.temakor = temakor;
                break;
            }
        }
    };
    TemakorComponent.prototype.goBack = function () {
        this.page.actionBarHidden = true;
        this.location.back();
    };
    TemakorComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "temakor",
            templateUrl: "temakor.component.html"
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], TemakorComponent);
    return TemakorComponent;
}());
exports.TemakorComponent = TemakorComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtYWtvci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0ZW1ha29yLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLFVBQVU7QUFDViwwQ0FBMkM7QUFDM0Msc0NBQWtEO0FBQ2xELDZEQUE0RDtBQUM1RCwwQ0FBeUM7QUFDekMsZ0NBQStCO0FBTy9CO0lBRUUsMEJBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFGVixXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixTQUFJLEdBQUosSUFBSSxDQUFNO1FBSnBCLFlBQU8sR0FBUSxFQUFFLENBQUM7SUFLZCxDQUFDO0lBRUUsbUNBQVEsR0FBZjtRQUNFLElBQU0sUUFBUSxHQUFHLGdDQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdkMsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFakQsR0FBRyxDQUFDLENBQWtCLFVBQVMsRUFBVCx1QkFBUyxFQUFULHVCQUFTLEVBQVQsSUFBUztZQUExQixJQUFNLE9BQU8sa0JBQUE7WUFDaEIsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUN2QixLQUFLLENBQUM7WUFDUixDQUFDO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsaUNBQU0sR0FBTjtRQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztRQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUF2QlUsZ0JBQWdCO1FBTDVCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsV0FBVyxFQUFFLHdCQUF3QjtTQUN0QyxDQUFDO3lDQUlrQixlQUFNO1lBQ0osaUJBQVE7WUFDWixXQUFJO09BTFQsZ0JBQWdCLENBd0I1QjtJQUFELHVCQUFDO0NBQUEsQUF4QkQsSUF3QkM7QUF4QlksNENBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQW5ndWxhclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBzZXRTdHJpbmcsIGdldFN0cmluZyB9IGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogXCJ0ZW1ha29yXCIsXG4gIHRlbXBsYXRlVXJsOiBcInRlbWFrb3IuY29tcG9uZW50Lmh0bWxcIlxufSlcbmV4cG9ydCBjbGFzcyBUZW1ha29yQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgdGVtYWtvcjogYW55ID0gW107XG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHsgfVxuXG4gIHB1YmxpYyBuZ09uSW5pdCgpIHtcbiAgICBjb25zdCBkYXRhSnNvbiA9IGdldFN0cmluZyhcImRhdGFKc29uXCIpO1xuICAgIGNvbnN0IHRlbWFrb3JvayA9IEpTT04ucGFyc2UoZGF0YUpzb24pLnRlbWFrb3JvaztcblxuICAgIGZvciAoY29uc3QgdGVtYWtvciBvZiB0ZW1ha29yb2spIHtcbiAgICAgIGlmICh0ZW1ha29yLnVybCA9PT0gdGhpcy5yb3V0ZXIudXJsKSB7XG4gICAgICAgIHRoaXMudGVtYWtvciA9IHRlbWFrb3I7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGdvQmFjaygpIHtcbiAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB0aGlzLmxvY2F0aW9uLmJhY2soKTtcbiAgfVxufVxuIl19