"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var OsztoTobbszorosComponent = (function (_super) {
    __extends(OsztoTobbszorosComponent, _super);
    function OsztoTobbszorosComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    OsztoTobbszorosComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'oszto-tobbszoros',
            templateUrl: './oszto-tobbszoros.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], OsztoTobbszorosComponent);
    return OsztoTobbszorosComponent;
}(tema_component_1.TemaComponent));
exports.OsztoTobbszorosComponent = OsztoTobbszorosComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3N6dG8tdG9iYnN6b3Jvcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJvc3p0by10b2Jic3pvcm9zLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBOEMsNENBQWE7SUFDekQsa0NBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSx3QkFBd0I7UUFMcEMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsa0JBQWtCO1lBQzVCLFdBQVcsRUFBRSxtQ0FBbUM7U0FDakQsQ0FBQzt5Q0FHa0IsZUFBTTtZQUNKLGlCQUFRO1lBQ1osV0FBSTtPQUpULHdCQUF3QixDQVFwQztJQUFELCtCQUFDO0NBQUEsQUFSRCxDQUE4Qyw4QkFBYSxHQVExRDtBQVJZLDREQUF3QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xuXG5pbXBvcnQgeyBUZW1hQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vdGVtYS5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgc2VsZWN0b3I6ICdvc3p0by10b2Jic3pvcm9zJyxcbiAgdGVtcGxhdGVVcmw6ICcuL29zenRvLXRvYmJzem9yb3MuY29tcG9uZW50Lmh0bWwnXG59KVxuZXhwb3J0IGNsYXNzIE9zenRvVG9iYnN6b3Jvc0NvbXBvbmVudCBleHRlbmRzIFRlbWFDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHtcbiAgICBzdXBlcihyb3V0ZXIsIGxvY2F0aW9uLCBwYWdlKTtcbiAgfVxufVxuIl19