"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var LegnagyobbLegkisebbComponent = (function (_super) {
    __extends(LegnagyobbLegkisebbComponent, _super);
    function LegnagyobbLegkisebbComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    LegnagyobbLegkisebbComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'legnagyobb-legkisebb',
            templateUrl: './legnagyobb-legkisebb.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], LegnagyobbLegkisebbComponent);
    return LegnagyobbLegkisebbComponent;
}(tema_component_1.TemaComponent));
exports.LegnagyobbLegkisebbComponent = LegnagyobbLegkisebbComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGVnbmFneW9iYi1sZWdraXNlYmIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGVnbmFneW9iYi1sZWdraXNlYmIuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUF5QztBQUN6QywwQ0FBMkM7QUFDM0MsZ0NBQStCO0FBRS9CLHVEQUFxRDtBQU9yRDtJQUFrRCxnREFBYTtJQUM3RCxzQ0FDVSxNQUFjLEVBQ2QsUUFBa0IsRUFDbEIsSUFBVTtRQUhwQixZQUtFLGtCQUFNLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQzlCO1FBTFMsWUFBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGNBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsVUFBSSxHQUFKLElBQUksQ0FBTTs7SUFHcEIsQ0FBQztJQVBVLDRCQUE0QjtRQUx4QyxnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxzQkFBc0I7WUFDaEMsV0FBVyxFQUFFLHVDQUF1QztTQUNyRCxDQUFDO3lDQUdrQixlQUFNO1lBQ0osaUJBQVE7WUFDWixXQUFJO09BSlQsNEJBQTRCLENBUXhDO0lBQUQsbUNBQUM7Q0FBQSxBQVJELENBQWtELDhCQUFhLEdBUTlEO0FBUlksb0VBQTRCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5cbmltcG9ydCB7IFRlbWFDb21wb25lbnQgfSBmcm9tICcuLi8uLi90ZW1hLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogJ2xlZ25hZ3lvYmItbGVna2lzZWJiJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2xlZ25hZ3lvYmItbGVna2lzZWJiLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBMZWduYWd5b2JiTGVna2lzZWJiQ29tcG9uZW50IGV4dGVuZHMgVGVtYUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkge1xuICAgIHN1cGVyKHJvdXRlciwgbG9jYXRpb24sIHBhZ2UpO1xuICB9XG59XG4iXX0=