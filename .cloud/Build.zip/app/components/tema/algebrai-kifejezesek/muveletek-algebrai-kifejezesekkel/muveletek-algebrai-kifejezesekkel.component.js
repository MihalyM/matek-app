"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var MuveletekAlgebraiKifejezesekelkComponent = (function (_super) {
    __extends(MuveletekAlgebraiKifejezesekelkComponent, _super);
    function MuveletekAlgebraiKifejezesekelkComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    MuveletekAlgebraiKifejezesekelkComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'muveletek-algebrai-kifejezesekkel',
            templateUrl: './muveletek-algebrai-kifejezesekkel.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], MuveletekAlgebraiKifejezesekelkComponent);
    return MuveletekAlgebraiKifejezesekelkComponent;
}(tema_component_1.TemaComponent));
exports.MuveletekAlgebraiKifejezesekelkComponent = MuveletekAlgebraiKifejezesekelkComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXV2ZWxldGVrLWFsZ2VicmFpLWtpZmVqZXplc2Vra2VsLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm11dmVsZXRlay1hbGdlYnJhaS1raWZlamV6ZXNla2tlbC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsMENBQXlDO0FBQ3pDLDBDQUEyQztBQUMzQyxnQ0FBK0I7QUFFL0IsdURBQXFEO0FBT3JEO0lBQThELDREQUFhO0lBQ3pFLGtEQUNVLE1BQWMsRUFDZCxRQUFrQixFQUNsQixJQUFVO1FBSHBCLFlBS0Usa0JBQU0sTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FDOUI7UUFMUyxZQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsY0FBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixVQUFJLEdBQUosSUFBSSxDQUFNOztJQUdwQixDQUFDO0lBUFUsd0NBQXdDO1FBTHBELGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLG1DQUFtQztZQUM3QyxXQUFXLEVBQUUsb0RBQW9EO1NBQ2xFLENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCx3Q0FBd0MsQ0FRcEQ7SUFBRCwrQ0FBQztDQUFBLEFBUkQsQ0FBOEQsOEJBQWEsR0FRMUU7QUFSWSw0RkFBd0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAnbXV2ZWxldGVrLWFsZ2VicmFpLWtpZmVqZXplc2Vra2VsJyxcbiAgdGVtcGxhdGVVcmw6ICcuL211dmVsZXRlay1hbGdlYnJhaS1raWZlamV6ZXNla2tlbC5jb21wb25lbnQuaHRtbCdcbn0pXG5leHBvcnQgY2xhc3MgTXV2ZWxldGVrQWxnZWJyYWlLaWZlamV6ZXNla2Vsa0NvbXBvbmVudCBleHRlbmRzIFRlbWFDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHtcbiAgICBzdXBlcihyb3V0ZXIsIGxvY2F0aW9uLCBwYWdlKTtcbiAgfVxufVxuIl19