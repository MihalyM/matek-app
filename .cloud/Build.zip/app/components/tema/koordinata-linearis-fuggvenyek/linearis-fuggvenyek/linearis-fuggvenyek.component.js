"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var LinearisFuggvenyekComponent = (function (_super) {
    __extends(LinearisFuggvenyekComponent, _super);
    function LinearisFuggvenyekComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    LinearisFuggvenyekComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'linearis-fuggvenyek',
            templateUrl: './linearis-fuggvenyek.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], LinearisFuggvenyekComponent);
    return LinearisFuggvenyekComponent;
}(tema_component_1.TemaComponent));
exports.LinearisFuggvenyekComponent = LinearisFuggvenyekComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGluZWFyaXMtZnVnZ3Zlbnllay5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsaW5lYXJpcy1mdWdndmVueWVrLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBaUQsK0NBQWE7SUFDNUQscUNBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSwyQkFBMkI7UUFMdkMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUscUJBQXFCO1lBQy9CLFdBQVcsRUFBRSxzQ0FBc0M7U0FDcEQsQ0FBQzt5Q0FHa0IsZUFBTTtZQUNKLGlCQUFRO1lBQ1osV0FBSTtPQUpULDJCQUEyQixDQVF2QztJQUFELGtDQUFDO0NBQUEsQUFSRCxDQUFpRCw4QkFBYSxHQVE3RDtBQVJZLGtFQUEyQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xuXG5pbXBvcnQgeyBUZW1hQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vdGVtYS5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgc2VsZWN0b3I6ICdsaW5lYXJpcy1mdWdndmVueWVrJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2xpbmVhcmlzLWZ1Z2d2ZW55ZWsuY29tcG9uZW50Lmh0bWwnXG59KVxuZXhwb3J0IGNsYXNzIExpbmVhcmlzRnVnZ3Zlbnlla0NvbXBvbmVudCBleHRlbmRzIFRlbWFDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHtcbiAgICBzdXBlcihyb3V0ZXIsIGxvY2F0aW9uLCBwYWdlKTtcbiAgfVxufVxuIl19