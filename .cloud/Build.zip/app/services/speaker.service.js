"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var SpeakerService = (function () {
    function SpeakerService() {
        this._speakers = [];
        var dataJson = application_settings_1.getString("dataJson");
        this._speakers = JSON.parse(dataJson).speakers;
    }
    SpeakerService.prototype._dynamicSort = function (property) {
        var sortOrder = 1;
        if (property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a, b) {
            var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
            return result * sortOrder;
        };
    };
    SpeakerService.prototype.getSpeakers = function () {
        this._speakers.sort(this._dynamicSort('name'));
        return this._speakers;
    };
    SpeakerService.prototype.getSpeakerById = function (id) {
        if (!id) {
            return;
        }
        return this._speakers.filter(function (speaker) {
            return speaker.id === id;
        })[0];
    };
    SpeakerService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], SpeakerService);
    return SpeakerService;
}());
exports.SpeakerService = SpeakerService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BlYWtlci5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic3BlYWtlci5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTJDO0FBRTNDLDZEQUFpRDtBQUtqRDtJQUdFO1FBRlEsY0FBUyxHQUFtQixFQUFFLENBQUM7UUFHckMsSUFBSSxRQUFRLEdBQUcsZ0NBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDO0lBQ2pELENBQUM7SUFFTyxxQ0FBWSxHQUFwQixVQUFxQixRQUFRO1FBQzNCLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN4QixTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDZixRQUFRLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoQyxDQUFDO1FBQ0QsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDbkIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwRixNQUFNLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUM1QixDQUFDLENBQUE7SUFDSCxDQUFDO0lBRUQsb0NBQVcsR0FBWDtRQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMvQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUN4QixDQUFDO0lBRUQsdUNBQWMsR0FBZCxVQUFlLEVBQVU7UUFDdkIsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ1IsTUFBTSxDQUFDO1FBQ1QsQ0FBQztRQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFDLE9BQU87WUFDbkMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1IsQ0FBQztJQWpDVSxjQUFjO1FBRDFCLGlCQUFVLEVBQUU7O09BQ0EsY0FBYyxDQW1DMUI7SUFBRCxxQkFBQztDQUFBLEFBbkNELElBbUNDO0FBbkNZLHdDQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBTcGVha2VyIH0gZnJvbSBcIi4vLi4vbW9kZWxzL3NwZWFrZXIubW9kZWxcIjtcbmltcG9ydCB7IGdldFN0cmluZyB9IGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuXG5kZWNsYXJlIHZhciBQcm9taXNlOiBhbnk7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBTcGVha2VyU2VydmljZSB7XG4gIHByaXZhdGUgX3NwZWFrZXJzOiBBcnJheTxTcGVha2VyPiA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIGxldCBkYXRhSnNvbiA9IGdldFN0cmluZyhcImRhdGFKc29uXCIpO1xuICAgIHRoaXMuX3NwZWFrZXJzID0gSlNPTi5wYXJzZShkYXRhSnNvbikuc3BlYWtlcnM7XG4gIH1cblxuICBwcml2YXRlIF9keW5hbWljU29ydChwcm9wZXJ0eSkge1xuICAgIHZhciBzb3J0T3JkZXIgPSAxO1xuICAgIGlmIChwcm9wZXJ0eVswXSA9PT0gXCItXCIpIHtcbiAgICAgIHNvcnRPcmRlciA9IC0xO1xuICAgICAgcHJvcGVydHkgPSBwcm9wZXJ0eS5zdWJzdHIoMSk7XG4gICAgfVxuICAgIHJldHVybiBmdW5jdGlvbiAoYSwgYikge1xuICAgICAgdmFyIHJlc3VsdCA9IChhW3Byb3BlcnR5XSA8IGJbcHJvcGVydHldKSA/IC0xIDogKGFbcHJvcGVydHldID4gYltwcm9wZXJ0eV0pID8gMSA6IDA7XG4gICAgICByZXR1cm4gcmVzdWx0ICogc29ydE9yZGVyO1xuICAgIH1cbiAgfVxuXG4gIGdldFNwZWFrZXJzKCk6IFNwZWFrZXJbXSB7XG4gICAgdGhpcy5fc3BlYWtlcnMuc29ydCh0aGlzLl9keW5hbWljU29ydCgnbmFtZScpKTtcbiAgICByZXR1cm4gdGhpcy5fc3BlYWtlcnM7XG4gIH1cblxuICBnZXRTcGVha2VyQnlJZChpZDogbnVtYmVyKTogU3BlYWtlciB7XG4gICAgaWYgKCFpZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl9zcGVha2Vycy5maWx0ZXIoKHNwZWFrZXIpID0+IHtcbiAgICAgIHJldHVybiBzcGVha2VyLmlkID09PSBpZDtcbiAgICB9KVswXTtcbiAgfVxuXG59XG4iXX0=