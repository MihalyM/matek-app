"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var _ = require("lodash");
var SessionService = (function () {
    function SessionService() {
        this._sessions = [];
        var dataJson = application_settings_1.getString("dataJson");
        this._sessions = JSON.parse(dataJson).sessions;
    }
    SessionService.prototype._dynamicSort = function (property) {
        var sortOrder = 1;
        if (property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a, b) {
            var result = a[property] < b[property] ? -1 : a[property] > b[property] ? 1 : 0;
            return result * sortOrder;
        };
    };
    SessionService.prototype.getSessions = function () {
        return this._sessions;
    };
    SessionService.prototype.getSession = function (id) {
        return this._sessions.filter(function (session) { return session.id === id; })[0];
    };
    SessionService.prototype.getSessionsBySpeaker = function (id) {
        return _.filter(this._sessions, { speaker: [{ id: id }] });
    };
    SessionService.prototype.getSessionsByType = function (type) {
        return _.filter(this._sessions, { type: type });
    };
    SessionService.prototype.getSessionsExcludingType = function (type) {
        this._sessions.sort(this._dynamicSort("start"));
        return _.filter(this._sessions, function (value) {
            return value.type !== type;
        });
    };
    SessionService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], SessionService);
    return SessionService;
}());
exports.SessionService = SessionService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2Vzc2lvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2Vzc2lvbi5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0Esc0NBQTJDO0FBQzNDLDZEQUFpRDtBQUVqRCwwQkFBNEI7QUFHNUI7SUFHRTtRQUZRLGNBQVMsR0FBbUIsRUFBRSxDQUFDO1FBR3JDLElBQUksUUFBUSxHQUFHLGdDQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQztJQUNqRCxDQUFDO0lBRU8scUNBQVksR0FBcEIsVUFBcUIsUUFBUTtRQUMzQixJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbEIsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDeEIsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2YsUUFBUSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEMsQ0FBQztRQUNELE1BQU0sQ0FBQyxVQUFTLENBQUMsRUFBRSxDQUFDO1lBQ2xCLElBQUksTUFBTSxHQUNSLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3JFLE1BQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1FBQzVCLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxvQ0FBVyxHQUFYO1FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDeEIsQ0FBQztJQUVELG1DQUFVLEdBQVYsVUFBVyxFQUFVO1FBQ25CLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFBLE9BQU8sSUFBSSxPQUFBLE9BQU8sQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFqQixDQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVELDZDQUFvQixHQUFwQixVQUFxQixFQUFVO1FBQzdCLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQsMENBQWlCLEdBQWpCLFVBQWtCLElBQVk7UUFDNUIsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCxpREFBd0IsR0FBeEIsVUFBeUIsSUFBWTtRQUNuQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDaEQsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFTLEtBQUs7WUFDNUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQTFDVSxjQUFjO1FBRDFCLGlCQUFVLEVBQUU7O09BQ0EsY0FBYyxDQTJDMUI7SUFBRCxxQkFBQztDQUFBLEFBM0NELElBMkNDO0FBM0NZLHdDQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gXCIuLy4uL21vZGVscy9zZXNzaW9uLm1vZGVsXCI7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IGdldFN0cmluZyB9IGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuXG5pbXBvcnQgKiBhcyBfIGZyb20gXCJsb2Rhc2hcIjtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFNlc3Npb25TZXJ2aWNlIHtcbiAgcHJpdmF0ZSBfc2Vzc2lvbnM6IEFycmF5PFNlc3Npb24+ID0gW107XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgbGV0IGRhdGFKc29uID0gZ2V0U3RyaW5nKFwiZGF0YUpzb25cIik7XG4gICAgdGhpcy5fc2Vzc2lvbnMgPSBKU09OLnBhcnNlKGRhdGFKc29uKS5zZXNzaW9ucztcbiAgfVxuXG4gIHByaXZhdGUgX2R5bmFtaWNTb3J0KHByb3BlcnR5KSB7XG4gICAgdmFyIHNvcnRPcmRlciA9IDE7XG4gICAgaWYgKHByb3BlcnR5WzBdID09PSBcIi1cIikge1xuICAgICAgc29ydE9yZGVyID0gLTE7XG4gICAgICBwcm9wZXJ0eSA9IHByb3BlcnR5LnN1YnN0cigxKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uKGEsIGIpIHtcbiAgICAgIHZhciByZXN1bHQgPVxuICAgICAgICBhW3Byb3BlcnR5XSA8IGJbcHJvcGVydHldID8gLTEgOiBhW3Byb3BlcnR5XSA+IGJbcHJvcGVydHldID8gMSA6IDA7XG4gICAgICByZXR1cm4gcmVzdWx0ICogc29ydE9yZGVyO1xuICAgIH07XG4gIH1cblxuICBnZXRTZXNzaW9ucygpOiBTZXNzaW9uW10ge1xuICAgIHJldHVybiB0aGlzLl9zZXNzaW9ucztcbiAgfVxuXG4gIGdldFNlc3Npb24oaWQ6IG51bWJlcik6IFNlc3Npb24ge1xuICAgIHJldHVybiB0aGlzLl9zZXNzaW9ucy5maWx0ZXIoc2Vzc2lvbiA9PiBzZXNzaW9uLmlkID09PSBpZClbMF07XG4gIH1cblxuICBnZXRTZXNzaW9uc0J5U3BlYWtlcihpZDogbnVtYmVyKSB7XG4gICAgcmV0dXJuIF8uZmlsdGVyKHRoaXMuX3Nlc3Npb25zLCB7IHNwZWFrZXI6IFt7IGlkOiBpZCB9XSB9KTtcbiAgfVxuXG4gIGdldFNlc3Npb25zQnlUeXBlKHR5cGU6IHN0cmluZykge1xuICAgIHJldHVybiBfLmZpbHRlcih0aGlzLl9zZXNzaW9ucywgeyB0eXBlOiB0eXBlIH0pO1xuICB9XG5cbiAgZ2V0U2Vzc2lvbnNFeGNsdWRpbmdUeXBlKHR5cGU6IHN0cmluZykge1xuICAgIHRoaXMuX3Nlc3Npb25zLnNvcnQodGhpcy5fZHluYW1pY1NvcnQoXCJzdGFydFwiKSk7XG4gICAgcmV0dXJuIF8uZmlsdGVyKHRoaXMuX3Nlc3Npb25zLCBmdW5jdGlvbih2YWx1ZSkge1xuICAgICAgcmV0dXJuIHZhbHVlLnR5cGUgIT09IHR5cGU7XG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==