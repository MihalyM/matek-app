"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var VenueService = (function () {
    function VenueService() {
        this._venues = [];
        var dataJson = application_settings_1.getString("dataJson");
        this._venues = JSON.parse(dataJson).venues;
    }
    VenueService.prototype.getVenues = function () {
        return this._venues;
    };
    VenueService.prototype.getVenueById = function (id) {
        return this._venues.filter(function (venue) { return venue.id === id; })[0];
    };
    VenueService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], VenueService);
    return VenueService;
}());
exports.VenueService = VenueService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVudWUuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInZlbnVlLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxzQ0FBMkM7QUFDM0MsNkRBQWlEO0FBR2pEO0lBR0U7UUFGUSxZQUFPLEdBQWlCLEVBQUUsQ0FBQztRQUdqQyxJQUFJLFFBQVEsR0FBRyxnQ0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7SUFDN0MsQ0FBQztJQUVELGdDQUFTLEdBQVQ7UUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN0QixDQUFDO0lBRUQsbUNBQVksR0FBWixVQUFhLEVBQVU7UUFDckIsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQWYsQ0FBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQWRVLFlBQVk7UUFEeEIsaUJBQVUsRUFBRTs7T0FDQSxZQUFZLENBZ0J4QjtJQUFELG1CQUFDO0NBQUEsQUFoQkQsSUFnQkM7QUFoQlksb0NBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBWZW51ZSB9IGZyb20gXCIuLy4uL21vZGVscy92ZW51ZS5tb2RlbFwiO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBnZXRTdHJpbmcgfSBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFZlbnVlU2VydmljZSB7XG4gIHByaXZhdGUgX3ZlbnVlczogQXJyYXk8VmVudWU+ID0gW107XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgbGV0IGRhdGFKc29uID0gZ2V0U3RyaW5nKFwiZGF0YUpzb25cIik7XG4gICAgdGhpcy5fdmVudWVzID0gSlNPTi5wYXJzZShkYXRhSnNvbikudmVudWVzO1xuICB9XG5cbiAgZ2V0VmVudWVzKCk6IFZlbnVlW10ge1xuICAgIHJldHVybiB0aGlzLl92ZW51ZXM7XG4gIH1cblxuICBnZXRWZW51ZUJ5SWQoaWQ6IG51bWJlcik6IFZlbnVlIHtcbiAgICByZXR1cm4gdGhpcy5fdmVudWVzLmZpbHRlcih2ZW51ZSA9PiB2ZW51ZS5pZCA9PT0gaWQpWzBdO1xuICB9XG5cbn1cbiJdfQ==