"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var EventService = (function () {
    function EventService() {
        this._events = [];
        var dataJson = application_settings_1.getString("dataJson");
        this._events = JSON.parse(dataJson).events;
    }
    EventService.prototype.getEventDay = function (day) {
        return this._events.filter(function (event) { return event.day === day; })[0];
    };
    EventService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], EventService);
    return EventService;
}());
exports.EventService = EventService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZlbnQuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImV2ZW50LnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxzQ0FBMkM7QUFDM0MsNkRBQWlEO0FBS2pEO0lBR0U7UUFGUSxZQUFPLEdBQWlCLEVBQUUsQ0FBQztRQUdqQyxJQUFJLFFBQVEsR0FBRyxnQ0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7SUFDN0MsQ0FBQztJQUVELGtDQUFXLEdBQVgsVUFBWSxHQUFXO1FBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUFqQixDQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQVZVLFlBQVk7UUFEeEIsaUJBQVUsRUFBRTs7T0FDQSxZQUFZLENBWXhCO0lBQUQsbUJBQUM7Q0FBQSxBQVpELElBWUM7QUFaWSxvQ0FBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEV2ZW50IH0gZnJvbSBcIi4vLi4vbW9kZWxzL2V2ZW50Lm1vZGVsXCI7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IGdldFN0cmluZyB9IGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBFdmVudFNlcnZpY2Uge1xuICBwcml2YXRlIF9ldmVudHM6IEFycmF5PEV2ZW50PiA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIGxldCBkYXRhSnNvbiA9IGdldFN0cmluZyhcImRhdGFKc29uXCIpO1xuICAgIHRoaXMuX2V2ZW50cyA9IEpTT04ucGFyc2UoZGF0YUpzb24pLmV2ZW50cztcbiAgfVxuXG4gIGdldEV2ZW50RGF5KGRheTogbnVtYmVyKTogRXZlbnQge1xuICAgIHJldHVybiB0aGlzLl9ldmVudHMuZmlsdGVyKGV2ZW50ID0+IGV2ZW50LmRheSA9PT0gZGF5KVswXTtcbiAgfVxuXG59XG4iXX0=