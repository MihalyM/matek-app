"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = (function () {
    function Config() {
    }
    Config.apiUrl = "";
    Config.apiAuthorization = "";
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFBQTtJQUdBLENBQUM7SUFGUSxhQUFNLEdBQUcsRUFBRSxDQUFDO0lBQ1osdUJBQWdCLEdBQUcsRUFBRSxDQUFDO0lBQy9CLGFBQUM7Q0FBQSxBQUhELElBR0M7QUFIWSx3QkFBTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb25maWcge1xuICBzdGF0aWMgYXBpVXJsID0gXCJcIjtcbiAgc3RhdGljIGFwaUF1dGhvcml6YXRpb24gPSBcIlwiO1xufVxuIl19