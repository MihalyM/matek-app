export class Config {
  static apiUrl = "";
  static apiAuthorization = "";
}
