"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Angular
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var application_settings_1 = require("application-settings");
var appversion = require("nativescript-appversion");
var platform_1 = require("platform");
var Http = require("http");
var HomeComponent = (function () {
    function HomeComponent(page, router) {
        this.page = page;
        this.router = router;
    }
    HomeComponent.prototype.ngOnInit = function () {
        this.page.actionBarHidden = true;
        this._getData();
        this._storeDeviceData();
    };
    HomeComponent.prototype._storeDeviceData = function () {
        var lDeviceJson = {
            device_uuid: platform_1.device.uuid,
            app_version_code: appversion.getVersionCodeSync(),
            app_version_name: appversion.getVersionNameSync(),
            device_type: platform_1.device.deviceType,
            device_language: platform_1.device.language,
            device_manufacturer: platform_1.device.manufacturer,
            device_model: platform_1.device.model,
            device_os: platform_1.device.os,
            device_os_version: platform_1.device.osVersion,
            device_sdk: platform_1.device.sdkVersion,
            device_screen_scale: platform_1.screen.mainScreen.scale,
            device_screen_height_dips: platform_1.screen.mainScreen.heightDIPs,
            device_screen_height_pixels: platform_1.screen.mainScreen.heightPixels,
            device_screen_width_dips: platform_1.screen.mainScreen.widthDIPs,
            device_screen_width_pixels: platform_1.screen.mainScreen.widthPixels
        };
        application_settings_1.setString("deviceJson", JSON.stringify(lDeviceJson));
    };
    HomeComponent.prototype._getData = function () {
        if (application_settings_1.getString("dataJson") === undefined) {
            var defaultData = require("../../data/default.json");
            application_settings_1.setString("dataJson", JSON.stringify(defaultData));
        }
    };
    HomeComponent.prototype.goToPage = function (url) {
        this.page.actionBarHidden = false;
        this.router.navigate([url]);
    };
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "home",
            templateUrl: "home.component.html"
        }),
        __metadata("design:paramtypes", [page_1.Page,
            router_1.Router])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLFVBQVU7QUFDVixzQ0FBaUU7QUFHakUsMENBQXlDO0FBR3pDLGdDQUErQjtBQUMvQiw2REFBNEQ7QUFHNUQsb0RBQXNEO0FBQ3RELHFDQUFpRDtBQUVqRCxJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFPM0I7SUFFRSx1QkFDVSxJQUFVLEVBQ1YsTUFBYztRQURkLFNBQUksR0FBSixJQUFJLENBQU07UUFDVixXQUFNLEdBQU4sTUFBTSxDQUFRO0lBQ3BCLENBQUM7SUFFTCxnQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU8sd0NBQWdCLEdBQXhCO1FBQ0UsSUFBSSxXQUFXLEdBQUc7WUFDaEIsV0FBVyxFQUFFLGlCQUFNLENBQUMsSUFBSTtZQUN4QixnQkFBZ0IsRUFBRSxVQUFVLENBQUMsa0JBQWtCLEVBQUU7WUFDakQsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLGtCQUFrQixFQUFFO1lBQ2pELFdBQVcsRUFBRSxpQkFBTSxDQUFDLFVBQVU7WUFDOUIsZUFBZSxFQUFFLGlCQUFNLENBQUMsUUFBUTtZQUNoQyxtQkFBbUIsRUFBRSxpQkFBTSxDQUFDLFlBQVk7WUFDeEMsWUFBWSxFQUFFLGlCQUFNLENBQUMsS0FBSztZQUMxQixTQUFTLEVBQUUsaUJBQU0sQ0FBQyxFQUFFO1lBQ3BCLGlCQUFpQixFQUFFLGlCQUFNLENBQUMsU0FBUztZQUNuQyxVQUFVLEVBQUUsaUJBQU0sQ0FBQyxVQUFVO1lBQzdCLG1CQUFtQixFQUFFLGlCQUFNLENBQUMsVUFBVSxDQUFDLEtBQUs7WUFDNUMseUJBQXlCLEVBQUUsaUJBQU0sQ0FBQyxVQUFVLENBQUMsVUFBVTtZQUN2RCwyQkFBMkIsRUFBRSxpQkFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZO1lBQzNELHdCQUF3QixFQUFFLGlCQUFNLENBQUMsVUFBVSxDQUFDLFNBQVM7WUFDckQsMEJBQTBCLEVBQUUsaUJBQU0sQ0FBQyxVQUFVLENBQUMsV0FBVztTQUMxRCxDQUFDO1FBQ0YsZ0NBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFTyxnQ0FBUSxHQUFoQjtRQUNFLEVBQUUsQ0FBQyxDQUFDLGdDQUFTLENBQUMsVUFBVSxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN4QyxJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztZQUNyRCxnQ0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDckQsQ0FBQztJQUNILENBQUM7SUFFRCxnQ0FBUSxHQUFSLFVBQVMsR0FBVztRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7UUFDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUE1Q1UsYUFBYTtRQUx6QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7U0FDbkMsQ0FBQzt5Q0FJZ0IsV0FBSTtZQUNGLGVBQU07T0FKYixhQUFhLENBNkN6QjtJQUFELG9CQUFDO0NBQUEsQUE3Q0QsSUE2Q0M7QUE3Q1ksc0NBQWEiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBbmd1bGFyXG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcblxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuXG5pbXBvcnQgKiBhcyBkaWFsb2dzIGZyb20gXCJ1aS9kaWFsb2dzXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcbmltcG9ydCB7IHNldFN0cmluZywgZ2V0U3RyaW5nIH0gZnJvbSBcImFwcGxpY2F0aW9uLXNldHRpbmdzXCI7XG5cbmltcG9ydCB7IENvbmZpZyB9IGZyb20gXCIuLi8uLi9zaGFyZWQvY29uZmlnXCI7XG5pbXBvcnQgKiBhcyBhcHB2ZXJzaW9uIGZyb20gXCJuYXRpdmVzY3JpcHQtYXBwdmVyc2lvblwiO1xuaW1wb3J0IHsgaXNJT1MsIGRldmljZSwgc2NyZWVuIH0gZnJvbSBcInBsYXRmb3JtXCI7XG5cbmxldCBIdHRwID0gcmVxdWlyZShcImh0dHBcIik7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogXCJob21lXCIsXG4gIHRlbXBsYXRlVXJsOiBcImhvbWUuY29tcG9uZW50Lmh0bWxcIlxufSlcbmV4cG9ydCBjbGFzcyBIb21lQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHBhZ2U6IFBhZ2UsXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlclxuICApIHsgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xuICAgIHRoaXMuX2dldERhdGEoKTtcbiAgICB0aGlzLl9zdG9yZURldmljZURhdGEoKTtcbiAgfVxuXG4gIHByaXZhdGUgX3N0b3JlRGV2aWNlRGF0YSgpIHtcbiAgICBsZXQgbERldmljZUpzb24gPSB7XG4gICAgICBkZXZpY2VfdXVpZDogZGV2aWNlLnV1aWQsXG4gICAgICBhcHBfdmVyc2lvbl9jb2RlOiBhcHB2ZXJzaW9uLmdldFZlcnNpb25Db2RlU3luYygpLFxuICAgICAgYXBwX3ZlcnNpb25fbmFtZTogYXBwdmVyc2lvbi5nZXRWZXJzaW9uTmFtZVN5bmMoKSxcbiAgICAgIGRldmljZV90eXBlOiBkZXZpY2UuZGV2aWNlVHlwZSxcbiAgICAgIGRldmljZV9sYW5ndWFnZTogZGV2aWNlLmxhbmd1YWdlLFxuICAgICAgZGV2aWNlX21hbnVmYWN0dXJlcjogZGV2aWNlLm1hbnVmYWN0dXJlcixcbiAgICAgIGRldmljZV9tb2RlbDogZGV2aWNlLm1vZGVsLFxuICAgICAgZGV2aWNlX29zOiBkZXZpY2Uub3MsXG4gICAgICBkZXZpY2Vfb3NfdmVyc2lvbjogZGV2aWNlLm9zVmVyc2lvbixcbiAgICAgIGRldmljZV9zZGs6IGRldmljZS5zZGtWZXJzaW9uLFxuICAgICAgZGV2aWNlX3NjcmVlbl9zY2FsZTogc2NyZWVuLm1haW5TY3JlZW4uc2NhbGUsXG4gICAgICBkZXZpY2Vfc2NyZWVuX2hlaWdodF9kaXBzOiBzY3JlZW4ubWFpblNjcmVlbi5oZWlnaHRESVBzLFxuICAgICAgZGV2aWNlX3NjcmVlbl9oZWlnaHRfcGl4ZWxzOiBzY3JlZW4ubWFpblNjcmVlbi5oZWlnaHRQaXhlbHMsXG4gICAgICBkZXZpY2Vfc2NyZWVuX3dpZHRoX2RpcHM6IHNjcmVlbi5tYWluU2NyZWVuLndpZHRoRElQcyxcbiAgICAgIGRldmljZV9zY3JlZW5fd2lkdGhfcGl4ZWxzOiBzY3JlZW4ubWFpblNjcmVlbi53aWR0aFBpeGVsc1xuICAgIH07XG4gICAgc2V0U3RyaW5nKFwiZGV2aWNlSnNvblwiLCBKU09OLnN0cmluZ2lmeShsRGV2aWNlSnNvbikpO1xuICB9XG5cbiAgcHJpdmF0ZSBfZ2V0RGF0YSgpIHtcbiAgICBpZiAoZ2V0U3RyaW5nKFwiZGF0YUpzb25cIikgPT09IHVuZGVmaW5lZCkge1xuICAgICAgbGV0IGRlZmF1bHREYXRhID0gcmVxdWlyZShcIi4uLy4uL2RhdGEvZGVmYXVsdC5qc29uXCIpO1xuICAgICAgc2V0U3RyaW5nKFwiZGF0YUpzb25cIiwgSlNPTi5zdHJpbmdpZnkoZGVmYXVsdERhdGEpKTtcbiAgICB9XG4gIH1cblxuICBnb1RvUGFnZSh1cmw6IHN0cmluZykge1xuICAgIHRoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSBmYWxzZTtcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdXJsXSk7XG4gIH1cbn1cbiJdfQ==