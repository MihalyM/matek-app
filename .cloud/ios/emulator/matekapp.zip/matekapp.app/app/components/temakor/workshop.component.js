"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Angular
var common_1 = require("@angular/common");
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var session_service_1 = require("./../../services/session.service");
var speaker_service_1 = require("./../../services/speaker.service");
var venue_service_1 = require("./../../services/venue.service");
var event_service_1 = require("./../../services/event.service");
var page_1 = require("ui/page");
var analytics_service_1 = require("../../services/analytics.service");
var WorkshopComponent = (function () {
    function WorkshopComponent(router, location, page, venueService, sessionService, speakerService, eventService, analyticsService) {
        this.router = router;
        this.location = location;
        this.page = page;
        this.venueService = venueService;
        this.sessionService = sessionService;
        this.speakerService = speakerService;
        this.eventService = eventService;
        this.analyticsService = analyticsService;
        this.speakers = [];
    }
    WorkshopComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.event = this.eventService.getEventDay(1);
        this.venue = this.venueService.getVenueById(this.event.venue);
        this.session = this.sessionService.getSessionsByType("WORKSHOP")[0];
        this.session.speaker.forEach(function (speaker) {
            _this.speakers.push(_this.speakerService.getSpeakerById(speaker.id));
        });
    };
    WorkshopComponent.prototype.ngAfterViewInit = function () {
        this.analyticsService.sendAnalytics("workshop");
    };
    WorkshopComponent.prototype.goBack = function () {
        this.page.actionBarHidden = true;
        this.location.back();
    };
    WorkshopComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "workshop",
            templateUrl: "workshop.component.html"
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page,
            venue_service_1.VenueService,
            session_service_1.SessionService,
            speaker_service_1.SpeakerService,
            event_service_1.EventService,
            analytics_service_1.AnalyticsService])
    ], WorkshopComponent);
    return WorkshopComponent;
}());
exports.WorkshopComponent = WorkshopComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid29ya3Nob3AuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsid29ya3Nob3AuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsVUFBVTtBQUNWLDBDQUEyQztBQUMzQyxzQ0FBaUU7QUFDakUsMENBQXlDO0FBQ3pDLG9FQUFrRTtBQUNsRSxvRUFBa0U7QUFDbEUsZ0VBQThEO0FBSzlELGdFQUE4RDtBQUM5RCxnQ0FBK0I7QUFDL0Isc0VBQW9FO0FBT3BFO0lBTUUsMkJBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVUsRUFDVixZQUEwQixFQUMxQixjQUE4QixFQUM5QixjQUE4QixFQUM5QixZQUEwQixFQUMxQixnQkFBa0M7UUFQbEMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGFBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsU0FBSSxHQUFKLElBQUksQ0FBTTtRQUNWLGlCQUFZLEdBQVosWUFBWSxDQUFjO1FBQzFCLG1CQUFjLEdBQWQsY0FBYyxDQUFnQjtRQUM5QixtQkFBYyxHQUFkLGNBQWMsQ0FBZ0I7UUFDOUIsaUJBQVksR0FBWixZQUFZLENBQWM7UUFDMUIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtRQVg1QyxhQUFRLEdBQW1CLEVBQUUsQ0FBQztJQVkzQixDQUFDO0lBRUcsb0NBQVEsR0FBZjtRQUFBLGlCQU9DO1FBTkMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFBLE9BQU87WUFDbEMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsMkNBQWUsR0FBZjtRQUNFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELGtDQUFNLEdBQU47UUFDRSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBakNVLGlCQUFpQjtRQUw3QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFdBQVcsRUFBRSx5QkFBeUI7U0FDdkMsQ0FBQzt5Q0FRa0IsZUFBTTtZQUNKLGlCQUFRO1lBQ1osV0FBSTtZQUNJLDRCQUFZO1lBQ1YsZ0NBQWM7WUFDZCxnQ0FBYztZQUNoQiw0QkFBWTtZQUNSLG9DQUFnQjtPQWRqQyxpQkFBaUIsQ0FrQzdCO0lBQUQsd0JBQUM7Q0FBQSxBQWxDRCxJQWtDQztBQWxDWSw4Q0FBaUIiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBbmd1bGFyXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBBZnRlclZpZXdJbml0IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IFNlc3Npb25TZXJ2aWNlIH0gZnJvbSBcIi4vLi4vLi4vc2VydmljZXMvc2Vzc2lvbi5zZXJ2aWNlXCI7XG5pbXBvcnQgeyBTcGVha2VyU2VydmljZSB9IGZyb20gXCIuLy4uLy4uL3NlcnZpY2VzL3NwZWFrZXIuc2VydmljZVwiO1xuaW1wb3J0IHsgVmVudWVTZXJ2aWNlIH0gZnJvbSBcIi4vLi4vLi4vc2VydmljZXMvdmVudWUuc2VydmljZVwiO1xuaW1wb3J0IHsgVmVudWUgfSBmcm9tIFwiLi8uLi8uLi9tb2RlbHMvdmVudWUubW9kZWxcIjtcbmltcG9ydCB7IFNlc3Npb24gfSBmcm9tIFwiLi8uLi8uLi9tb2RlbHMvc2Vzc2lvbi5tb2RlbFwiO1xuaW1wb3J0IHsgU3BlYWtlciB9IGZyb20gXCIuLy4uLy4uL21vZGVscy9zcGVha2VyLm1vZGVsXCI7XG5pbXBvcnQgeyBFdmVudCB9IGZyb20gXCIuLy4uLy4uL21vZGVscy9ldmVudC5tb2RlbFwiO1xuaW1wb3J0IHsgRXZlbnRTZXJ2aWNlIH0gZnJvbSBcIi4vLi4vLi4vc2VydmljZXMvZXZlbnQuc2VydmljZVwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5pbXBvcnQgeyBBbmFseXRpY3NTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL2FuYWx5dGljcy5zZXJ2aWNlXCI7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogXCJ3b3Jrc2hvcFwiLFxuICB0ZW1wbGF0ZVVybDogXCJ3b3Jrc2hvcC5jb21wb25lbnQuaHRtbFwiXG59KVxuZXhwb3J0IGNsYXNzIFdvcmtzaG9wQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgdmVudWU6IFZlbnVlO1xuICBzZXNzaW9uOiBTZXNzaW9uO1xuICBzcGVha2VyczogQXJyYXk8U3BlYWtlcj4gPSBbXTtcbiAgZXZlbnQ6IEV2ZW50O1xuXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZSxcbiAgICBwcml2YXRlIHZlbnVlU2VydmljZTogVmVudWVTZXJ2aWNlLFxuICAgIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLFxuICAgIHByaXZhdGUgc3BlYWtlclNlcnZpY2U6IFNwZWFrZXJTZXJ2aWNlLFxuICAgIHByaXZhdGUgZXZlbnRTZXJ2aWNlOiBFdmVudFNlcnZpY2UsXG4gICAgcHJpdmF0ZSBhbmFseXRpY3NTZXJ2aWNlOiBBbmFseXRpY3NTZXJ2aWNlXG4gICkge31cblxuICBwdWJsaWMgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5ldmVudCA9IHRoaXMuZXZlbnRTZXJ2aWNlLmdldEV2ZW50RGF5KDEpO1xuICAgIHRoaXMudmVudWUgPSB0aGlzLnZlbnVlU2VydmljZS5nZXRWZW51ZUJ5SWQodGhpcy5ldmVudC52ZW51ZSk7XG4gICAgdGhpcy5zZXNzaW9uID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uc0J5VHlwZShcIldPUktTSE9QXCIpWzBdO1xuICAgIHRoaXMuc2Vzc2lvbi5zcGVha2VyLmZvckVhY2goc3BlYWtlciA9PiB7XG4gICAgICB0aGlzLnNwZWFrZXJzLnB1c2godGhpcy5zcGVha2VyU2VydmljZS5nZXRTcGVha2VyQnlJZChzcGVha2VyLmlkKSk7XG4gICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5hbmFseXRpY3NTZXJ2aWNlLnNlbmRBbmFseXRpY3MoXCJ3b3Jrc2hvcFwiKTtcbiAgfVxuXG4gIGdvQmFjaygpIHtcbiAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB0aGlzLmxvY2F0aW9uLmJhY2soKTtcbiAgfVxufVxuIl19