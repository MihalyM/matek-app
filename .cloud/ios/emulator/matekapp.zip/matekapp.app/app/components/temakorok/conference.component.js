"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Angular
var common_1 = require("@angular/common");
var session_service_1 = require("./../../services/session.service");
var venue_service_1 = require("./../../services/venue.service");
var event_service_1 = require("./../../services/event.service");
var analytics_service_1 = require("../../services/analytics.service");
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var ConferenceComponent = (function () {
    function ConferenceComponent(router, location, page, venueService, sessionService, eventService, analyticsService) {
        this.router = router;
        this.location = location;
        this.page = page;
        this.venueService = venueService;
        this.sessionService = sessionService;
        this.eventService = eventService;
        this.analyticsService = analyticsService;
    }
    ConferenceComponent.prototype.ngOnInit = function () {
        this.event = this.eventService.getEventDay(2);
        this.venue = this.venueService.getVenueById(this.event.venue);
        this.sessions = this.sessionService.getSessionsExcludingType("WORKSHOP");
    };
    ConferenceComponent.prototype.ngAfterViewInit = function () {
        this.analyticsService.sendAnalytics("conference");
    };
    ConferenceComponent.prototype.goBack = function () {
        this.page.actionBarHidden = true;
        this.location.back();
    };
    ConferenceComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "conference",
            templateUrl: "conference.component.html"
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page,
            venue_service_1.VenueService,
            session_service_1.SessionService,
            event_service_1.EventService,
            analytics_service_1.AnalyticsService])
    ], ConferenceComponent);
    return ConferenceComponent;
}());
exports.ConferenceComponent = ConferenceComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmVyZW5jZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25mZXJlbmNlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLFVBQVU7QUFDViwwQ0FBMkM7QUFHM0Msb0VBQWtFO0FBRWxFLGdFQUE4RDtBQUU5RCxnRUFBOEQ7QUFDOUQsc0VBQW9FO0FBQ3BFLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsZ0NBQStCO0FBTy9CO0lBS0UsNkJBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVUsRUFDVixZQUEwQixFQUMxQixjQUE4QixFQUM5QixZQUEwQixFQUMxQixnQkFBa0M7UUFObEMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGFBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsU0FBSSxHQUFKLElBQUksQ0FBTTtRQUNWLGlCQUFZLEdBQVosWUFBWSxDQUFjO1FBQzFCLG1CQUFjLEdBQWQsY0FBYyxDQUFnQjtRQUM5QixpQkFBWSxHQUFaLFlBQVksQ0FBYztRQUMxQixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO0lBQ3pDLENBQUM7SUFFSixzQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFFRCw2Q0FBZSxHQUFmO1FBQ0UsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsb0NBQU0sR0FBTjtRQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztRQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUE1QlUsbUJBQW1CO1FBTC9CLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLFlBQVk7WUFDdEIsV0FBVyxFQUFFLDJCQUEyQjtTQUN6QyxDQUFDO3lDQU9rQixlQUFNO1lBQ0osaUJBQVE7WUFDWixXQUFJO1lBQ0ksNEJBQVk7WUFDVixnQ0FBYztZQUNoQiw0QkFBWTtZQUNSLG9DQUFnQjtPQVpqQyxtQkFBbUIsQ0E2Qi9CO0lBQUQsMEJBQUM7Q0FBQSxBQTdCRCxJQTZCQztBQTdCWSxrREFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBbmd1bGFyXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcblxuaW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gXCIuLy4uLy4uL21vZGVscy9zZXNzaW9uLm1vZGVsXCI7XG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSB9IGZyb20gXCIuLy4uLy4uL3NlcnZpY2VzL3Nlc3Npb24uc2VydmljZVwiO1xuaW1wb3J0IHsgVmVudWUgfSBmcm9tIFwiLi8uLi8uLi9tb2RlbHMvdmVudWUubW9kZWxcIjtcbmltcG9ydCB7IFZlbnVlU2VydmljZSB9IGZyb20gXCIuLy4uLy4uL3NlcnZpY2VzL3ZlbnVlLnNlcnZpY2VcIjtcbmltcG9ydCB7IEV2ZW50IH0gZnJvbSBcIi4vLi4vLi4vbW9kZWxzL2V2ZW50Lm1vZGVsXCI7XG5pbXBvcnQgeyBFdmVudFNlcnZpY2UgfSBmcm9tIFwiLi8uLi8uLi9zZXJ2aWNlcy9ldmVudC5zZXJ2aWNlXCI7XG5pbXBvcnQgeyBBbmFseXRpY3NTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL2FuYWx5dGljcy5zZXJ2aWNlXCI7XG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiBcImNvbmZlcmVuY2VcIixcbiAgdGVtcGxhdGVVcmw6IFwiY29uZmVyZW5jZS5jb21wb25lbnQuaHRtbFwiXG59KVxuZXhwb3J0IGNsYXNzIENvbmZlcmVuY2VDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBzZXNzaW9uczogQXJyYXk8U2Vzc2lvbj47XG4gIHZlbnVlOiBWZW51ZTtcbiAgZXZlbnQ6IEV2ZW50O1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlLFxuICAgIHByaXZhdGUgdmVudWVTZXJ2aWNlOiBWZW51ZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSBzZXNzaW9uU2VydmljZTogU2Vzc2lvblNlcnZpY2UsXG4gICAgcHJpdmF0ZSBldmVudFNlcnZpY2U6IEV2ZW50U2VydmljZSxcbiAgICBwcml2YXRlIGFuYWx5dGljc1NlcnZpY2U6IEFuYWx5dGljc1NlcnZpY2VcbiAgKSB7fVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMuZXZlbnQgPSB0aGlzLmV2ZW50U2VydmljZS5nZXRFdmVudERheSgyKTtcbiAgICB0aGlzLnZlbnVlID0gdGhpcy52ZW51ZVNlcnZpY2UuZ2V0VmVudWVCeUlkKHRoaXMuZXZlbnQudmVudWUpO1xuICAgIHRoaXMuc2Vzc2lvbnMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25zRXhjbHVkaW5nVHlwZShcIldPUktTSE9QXCIpO1xuICB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMuYW5hbHl0aWNzU2VydmljZS5zZW5kQW5hbHl0aWNzKFwiY29uZmVyZW5jZVwiKTtcbiAgfVxuXG4gIGdvQmFjaygpIHtcbiAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB0aGlzLmxvY2F0aW9uLmJhY2soKTtcbiAgfVxufVxuIl19