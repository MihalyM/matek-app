"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Angular
var common_1 = require("@angular/common");
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var page_1 = require("ui/page");
var TemakorokComponent = (function () {
    function TemakorokComponent(location, page) {
        this.location = location;
        this.page = page;
        this.temakorok = [];
    }
    TemakorokComponent.prototype.ngOnInit = function () {
        var dataJson = application_settings_1.getString("dataJson");
        this.temakorok = JSON.parse(dataJson).temakorok;
    };
    TemakorokComponent.prototype.ngAfterViewInit = function () {
    };
    TemakorokComponent.prototype.goBack = function () {
        this.page.actionBarHidden = true;
        this.location.back();
    };
    TemakorokComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "temakorok",
            templateUrl: "temakorok.component.html"
        }),
        __metadata("design:paramtypes", [common_1.Location,
            page_1.Page])
    ], TemakorokComponent);
    return TemakorokComponent;
}());
exports.TemakorokComponent = TemakorokComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtYWtvcm9rLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRlbWFrb3Jvay5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxVQUFVO0FBQ1YsMENBQTJDO0FBQzNDLHNDQUFrRDtBQUNsRCw2REFBNEQ7QUFDNUQsZ0NBQStCO0FBTy9CO0lBRUUsNEJBQ1UsUUFBa0IsRUFDbEIsSUFBVTtRQURWLGFBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsU0FBSSxHQUFKLElBQUksQ0FBTTtRQUhwQixjQUFTLEdBQVEsRUFBRSxDQUFDO0lBSWhCLENBQUM7SUFFTCxxQ0FBUSxHQUFSO1FBQ0UsSUFBTSxRQUFRLEdBQUcsZ0NBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQ2xELENBQUM7SUFFRCw0Q0FBZSxHQUFmO0lBQ0EsQ0FBQztJQUVELG1DQUFNLEdBQU47UUFDRSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBbEJVLGtCQUFrQjtRQUw5QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxXQUFXO1lBQ3JCLFdBQVcsRUFBRSwwQkFBMEI7U0FDeEMsQ0FBQzt5Q0FJb0IsaUJBQVE7WUFDWixXQUFJO09BSlQsa0JBQWtCLENBbUI5QjtJQUFELHlCQUFDO0NBQUEsQUFuQkQsSUFtQkM7QUFuQlksZ0RBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQW5ndWxhclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBzZXRTdHJpbmcsIGdldFN0cmluZyB9IGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogXCJ0ZW1ha29yb2tcIixcbiAgdGVtcGxhdGVVcmw6IFwidGVtYWtvcm9rLmNvbXBvbmVudC5odG1sXCJcbn0pXG5leHBvcnQgY2xhc3MgVGVtYWtvcm9rQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgdGVtYWtvcm9rOiBhbnkgPSBbXTtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkgeyB9XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgY29uc3QgZGF0YUpzb24gPSBnZXRTdHJpbmcoXCJkYXRhSnNvblwiKTtcbiAgICB0aGlzLnRlbWFrb3JvayA9IEpTT04ucGFyc2UoZGF0YUpzb24pLnRlbWFrb3JvaztcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgfVxuXG4gIGdvQmFjaygpIHtcbiAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB0aGlzLmxvY2F0aW9uLmJhY2soKTtcbiAgfVxufVxuIl19