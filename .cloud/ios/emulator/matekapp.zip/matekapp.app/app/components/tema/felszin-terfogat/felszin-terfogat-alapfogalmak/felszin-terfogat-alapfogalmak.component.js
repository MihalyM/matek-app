"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var FelszinTerfogatAlapfogalmakComponent = (function (_super) {
    __extends(FelszinTerfogatAlapfogalmakComponent, _super);
    function FelszinTerfogatAlapfogalmakComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    FelszinTerfogatAlapfogalmakComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'felszin-terfogat-alapfogalmak',
            templateUrl: './felszin-terfogat-alapfogalmak.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], FelszinTerfogatAlapfogalmakComponent);
    return FelszinTerfogatAlapfogalmakComponent;
}(tema_component_1.TemaComponent));
exports.FelszinTerfogatAlapfogalmakComponent = FelszinTerfogatAlapfogalmakComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmVsc3ppbi10ZXJmb2dhdC1hbGFwZm9nYWxtYWsuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmVsc3ppbi10ZXJmb2dhdC1hbGFwZm9nYWxtYWsuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUF5QztBQUN6QywwQ0FBMkM7QUFDM0MsZ0NBQStCO0FBRS9CLHVEQUFxRDtBQU9yRDtJQUEwRCx3REFBYTtJQUNyRSw4Q0FDVSxNQUFjLEVBQ2QsUUFBa0IsRUFDbEIsSUFBVTtRQUhwQixZQUtFLGtCQUFNLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQzlCO1FBTFMsWUFBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGNBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsVUFBSSxHQUFKLElBQUksQ0FBTTs7SUFHcEIsQ0FBQztJQVBVLG9DQUFvQztRQUxoRCxnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSwrQkFBK0I7WUFDekMsV0FBVyxFQUFFLGdEQUFnRDtTQUM5RCxDQUFDO3lDQUdrQixlQUFNO1lBQ0osaUJBQVE7WUFDWixXQUFJO09BSlQsb0NBQW9DLENBUWhEO0lBQUQsMkNBQUM7Q0FBQSxBQVJELENBQTBELDhCQUFhLEdBUXRFO0FBUlksb0ZBQW9DIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5cbmltcG9ydCB7IFRlbWFDb21wb25lbnQgfSBmcm9tICcuLi8uLi90ZW1hLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICBzZWxlY3RvcjogJ2ZlbHN6aW4tdGVyZm9nYXQtYWxhcGZvZ2FsbWFrJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2ZlbHN6aW4tdGVyZm9nYXQtYWxhcGZvZ2FsbWFrLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBGZWxzemluVGVyZm9nYXRBbGFwZm9nYWxtYWtDb21wb25lbnQgZXh0ZW5kcyBUZW1hQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgICBwcml2YXRlIHBhZ2U6IFBhZ2VcbiAgKSB7XG4gICAgc3VwZXIocm91dGVyLCBsb2NhdGlvbiwgcGFnZSk7XG4gIH1cbn1cbiJdfQ==