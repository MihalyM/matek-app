"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var SzamhalmazMuveletekComponent = (function (_super) {
    __extends(SzamhalmazMuveletekComponent, _super);
    function SzamhalmazMuveletekComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    SzamhalmazMuveletekComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'statisztika',
            templateUrl: './szamhalmaz-muveletek.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], SzamhalmazMuveletekComponent);
    return SzamhalmazMuveletekComponent;
}(tema_component_1.TemaComponent));
exports.SzamhalmazMuveletekComponent = SzamhalmazMuveletekComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3phbWhhbG1hei1tdXZlbGV0ZWsuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic3phbWhhbG1hei1tdXZlbGV0ZWsuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUF5QztBQUN6QywwQ0FBMkM7QUFDM0MsZ0NBQStCO0FBRS9CLHVEQUFxRDtBQU9yRDtJQUFrRCxnREFBYTtJQUM3RCxzQ0FDVSxNQUFjLEVBQ2QsUUFBa0IsRUFDbEIsSUFBVTtRQUhwQixZQUtFLGtCQUFNLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQzlCO1FBTFMsWUFBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGNBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsVUFBSSxHQUFKLElBQUksQ0FBTTs7SUFHcEIsQ0FBQztJQVBVLDRCQUE0QjtRQUx4QyxnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxhQUFhO1lBQ3ZCLFdBQVcsRUFBRSx1Q0FBdUM7U0FDckQsQ0FBQzt5Q0FHa0IsZUFBTTtZQUNKLGlCQUFRO1lBQ1osV0FBSTtPQUpULDRCQUE0QixDQVF4QztJQUFELG1DQUFDO0NBQUEsQUFSRCxDQUFrRCw4QkFBYSxHQVE5RDtBQVJZLG9FQUE0QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xuXG5pbXBvcnQgeyBUZW1hQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vdGVtYS5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgc2VsZWN0b3I6ICdzdGF0aXN6dGlrYScsXG4gIHRlbXBsYXRlVXJsOiAnLi9zemFtaGFsbWF6LW11dmVsZXRlay5jb21wb25lbnQuaHRtbCdcbn0pXG5leHBvcnQgY2xhc3MgU3phbWhhbG1hek11dmVsZXRla0NvbXBvbmVudCBleHRlbmRzIFRlbWFDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgIHByaXZhdGUgcGFnZTogUGFnZVxuICApIHtcbiAgICBzdXBlcihyb3V0ZXIsIGxvY2F0aW9uLCBwYWdlKTtcbiAgfVxufVxuIl19