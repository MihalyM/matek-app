"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var SzovegesAltalanosComponent = (function (_super) {
    __extends(SzovegesAltalanosComponent, _super);
    function SzovegesAltalanosComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    SzovegesAltalanosComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'szoveges-altalanos',
            templateUrl: './szoveges-altalanos.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], SzovegesAltalanosComponent);
    return SzovegesAltalanosComponent;
}(tema_component_1.TemaComponent));
exports.SzovegesAltalanosComponent = SzovegesAltalanosComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3pvdmVnZXMtYWx0YWxhbm9zLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInN6b3ZlZ2VzLWFsdGFsYW5vcy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsMENBQXlDO0FBQ3pDLDBDQUEyQztBQUMzQyxnQ0FBK0I7QUFFL0IsdURBQXFEO0FBT3JEO0lBQWdELDhDQUFhO0lBQzNELG9DQUNVLE1BQWMsRUFDZCxRQUFrQixFQUNsQixJQUFVO1FBSHBCLFlBS0Usa0JBQU0sTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FDOUI7UUFMUyxZQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsY0FBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixVQUFJLEdBQUosSUFBSSxDQUFNOztJQUdwQixDQUFDO0lBUFUsMEJBQTBCO1FBTHRDLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLG9CQUFvQjtZQUM5QixXQUFXLEVBQUUscUNBQXFDO1NBQ25ELENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCwwQkFBMEIsQ0FRdEM7SUFBRCxpQ0FBQztDQUFBLEFBUkQsQ0FBZ0QsOEJBQWEsR0FRNUQ7QUFSWSxnRUFBMEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAnc3pvdmVnZXMtYWx0YWxhbm9zJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3N6b3ZlZ2VzLWFsdGFsYW5vcy5jb21wb25lbnQuaHRtbCdcbn0pXG5leHBvcnQgY2xhc3MgU3pvdmVnZXNBbHRhbGFub3NDb21wb25lbnQgZXh0ZW5kcyBUZW1hQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgICBwcml2YXRlIHBhZ2U6IFBhZ2VcbiAgKSB7XG4gICAgc3VwZXIocm91dGVyLCBsb2NhdGlvbiwgcGFnZSk7XG4gIH1cbn1cbiJdfQ==