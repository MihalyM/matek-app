"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var TeruletComponent = (function (_super) {
    __extends(TeruletComponent, _super);
    function TeruletComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    TeruletComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'terulet',
            templateUrl: './terulet.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], TeruletComponent);
    return TeruletComponent;
}(tema_component_1.TemaComponent));
exports.TeruletComponent = TeruletComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVydWxldC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0ZXJ1bGV0LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBc0Msb0NBQWE7SUFDakQsMEJBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSxnQkFBZ0I7UUFMNUIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsU0FBUztZQUNuQixXQUFXLEVBQUUsMEJBQTBCO1NBQ3hDLENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCxnQkFBZ0IsQ0FRNUI7SUFBRCx1QkFBQztDQUFBLEFBUkQsQ0FBc0MsOEJBQWEsR0FRbEQ7QUFSWSw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAndGVydWxldCcsXG4gIHRlbXBsYXRlVXJsOiAnLi90ZXJ1bGV0LmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBUZXJ1bGV0Q29tcG9uZW50IGV4dGVuZHMgVGVtYUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkge1xuICAgIHN1cGVyKHJvdXRlciwgbG9jYXRpb24sIHBhZ2UpO1xuICB9XG59XG4iXX0=