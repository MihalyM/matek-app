"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var KombinatorikaComponent = (function (_super) {
    __extends(KombinatorikaComponent, _super);
    function KombinatorikaComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    KombinatorikaComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'kombinatorika',
            templateUrl: './kombinatorika.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], KombinatorikaComponent);
    return KombinatorikaComponent;
}(tema_component_1.TemaComponent));
exports.KombinatorikaComponent = KombinatorikaComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia29tYmluYXRvcmlrYS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJrb21iaW5hdG9yaWthLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBNEMsMENBQWE7SUFDdkQsZ0NBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSxzQkFBc0I7UUFMbEMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsZUFBZTtZQUN6QixXQUFXLEVBQUUsZ0NBQWdDO1NBQzlDLENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCxzQkFBc0IsQ0FRbEM7SUFBRCw2QkFBQztDQUFBLEFBUkQsQ0FBNEMsOEJBQWEsR0FReEQ7QUFSWSx3REFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAna29tYmluYXRvcmlrYScsXG4gIHRlbXBsYXRlVXJsOiAnLi9rb21iaW5hdG9yaWthLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBLb21iaW5hdG9yaWthQ29tcG9uZW50IGV4dGVuZHMgVGVtYUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlXG4gICkge1xuICAgIHN1cGVyKHJvdXRlciwgbG9jYXRpb24sIHBhZ2UpO1xuICB9XG59XG4iXX0=