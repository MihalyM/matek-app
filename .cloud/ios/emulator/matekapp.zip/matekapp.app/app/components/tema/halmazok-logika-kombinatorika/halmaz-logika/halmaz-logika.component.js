"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var page_1 = require("ui/page");
var tema_component_1 = require("../../tema.component");
var HalmazLogikaComponent = (function (_super) {
    __extends(HalmazLogikaComponent, _super);
    function HalmazLogikaComponent(router, location, page) {
        var _this = _super.call(this, router, location, page) || this;
        _this.router = router;
        _this.location = location;
        _this.page = page;
        return _this;
    }
    HalmazLogikaComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'halmaz-logika',
            templateUrl: './halmaz-logika.component.html'
        }),
        __metadata("design:paramtypes", [router_1.Router,
            common_1.Location,
            page_1.Page])
    ], HalmazLogikaComponent);
    return HalmazLogikaComponent;
}(tema_component_1.TemaComponent));
exports.HalmazLogikaComponent = HalmazLogikaComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFsbWF6LWxvZ2lrYS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJoYWxtYXotbG9naWthLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCwwQ0FBeUM7QUFDekMsMENBQTJDO0FBQzNDLGdDQUErQjtBQUUvQix1REFBcUQ7QUFPckQ7SUFBMkMseUNBQWE7SUFDdEQsK0JBQ1UsTUFBYyxFQUNkLFFBQWtCLEVBQ2xCLElBQVU7UUFIcEIsWUFLRSxrQkFBTSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUM5QjtRQUxTLFlBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxjQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLFVBQUksR0FBSixJQUFJLENBQU07O0lBR3BCLENBQUM7SUFQVSxxQkFBcUI7UUFMakMsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsZUFBZTtZQUN6QixXQUFXLEVBQUUsZ0NBQWdDO1NBQzlDLENBQUM7eUNBR2tCLGVBQU07WUFDSixpQkFBUTtZQUNaLFdBQUk7T0FKVCxxQkFBcUIsQ0FRakM7SUFBRCw0QkFBQztDQUFBLEFBUkQsQ0FBMkMsOEJBQWEsR0FRdkQ7QUFSWSxzREFBcUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcblxuaW1wb3J0IHsgVGVtYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL3RlbWEuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHNlbGVjdG9yOiAnaGFsbWF6LWxvZ2lrYScsXG4gIHRlbXBsYXRlVXJsOiAnLi9oYWxtYXotbG9naWthLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBIYWxtYXpMb2dpa2FDb21wb25lbnQgZXh0ZW5kcyBUZW1hQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgICBwcml2YXRlIHBhZ2U6IFBhZ2VcbiAgKSB7XG4gICAgc3VwZXIocm91dGVyLCBsb2NhdGlvbiwgcGFnZSk7XG4gIH1cbn1cbiJdfQ==