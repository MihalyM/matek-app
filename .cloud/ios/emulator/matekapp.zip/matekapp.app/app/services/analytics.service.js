"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var application_settings_1 = require("application-settings");
var config_1 = require("../shared/config");
var Http = require("http");
var AnalyticsService = (function () {
    function AnalyticsService() {
        this._events = [];
    }
    AnalyticsService.prototype.sendAnalytics = function (page) {
        Http.request({
            url: config_1.Config.apiUrl + "/analytics/",
            method: "POST",
            headers: {
                Authorization: "Basic " + config_1.Config.apiAuthorization,
                "Content-Type": "application/json",
                "X-Page": page
            },
            content: application_settings_1.getString("deviceJson")
        }).then(function (response) {
            // console.log(response.statusCode);
        }, function (e) {
            // console.log("Error occurred " + e);
        });
    };
    AnalyticsService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], AnalyticsService);
    return AnalyticsService;
}());
exports.AnalyticsService = AnalyticsService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5hbHl0aWNzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhbmFseXRpY3Muc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyQztBQUMzQyw2REFBaUQ7QUFDakQsMkNBQTBDO0FBRTFDLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUczQjtJQUdFO1FBRlEsWUFBTyxHQUFpQixFQUFFLENBQUM7SUFFcEIsQ0FBQztJQUVoQix3Q0FBYSxHQUFiLFVBQWMsSUFBWTtRQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDO1lBQ1gsR0FBRyxFQUFFLGVBQU0sQ0FBQyxNQUFNLEdBQUcsYUFBYTtZQUNsQyxNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRTtnQkFDUCxhQUFhLEVBQUUsUUFBUSxHQUFHLGVBQU0sQ0FBQyxnQkFBZ0I7Z0JBQ2pELGNBQWMsRUFBRSxrQkFBa0I7Z0JBQ2xDLFFBQVEsRUFBRSxJQUFJO2FBQ2Y7WUFDRCxPQUFPLEVBQUUsZ0NBQVMsQ0FBQyxZQUFZLENBQUM7U0FDakMsQ0FBQyxDQUFDLElBQUksQ0FDTCxVQUFTLFFBQVE7WUFDZixvQ0FBb0M7UUFDdEMsQ0FBQyxFQUNELFVBQVMsQ0FBQztZQUNSLHNDQUFzQztRQUN4QyxDQUFDLENBQ0YsQ0FBQztJQUNKLENBQUM7SUF2QlUsZ0JBQWdCO1FBRDVCLGlCQUFVLEVBQUU7O09BQ0EsZ0JBQWdCLENBd0I1QjtJQUFELHVCQUFDO0NBQUEsQUF4QkQsSUF3QkM7QUF4QlksNENBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBnZXRTdHJpbmcgfSBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gXCIuLi9zaGFyZWQvY29uZmlnXCI7XG5cbmxldCBIdHRwID0gcmVxdWlyZShcImh0dHBcIik7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBBbmFseXRpY3NTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBfZXZlbnRzOiBBcnJheTxFdmVudD4gPSBbXTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgc2VuZEFuYWx5dGljcyhwYWdlOiBzdHJpbmcpIHtcbiAgICBIdHRwLnJlcXVlc3Qoe1xuICAgICAgdXJsOiBDb25maWcuYXBpVXJsICsgXCIvYW5hbHl0aWNzL1wiLFxuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQXV0aG9yaXphdGlvbjogXCJCYXNpYyBcIiArIENvbmZpZy5hcGlBdXRob3JpemF0aW9uLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJYLVBhZ2VcIjogcGFnZVxuICAgICAgfSxcbiAgICAgIGNvbnRlbnQ6IGdldFN0cmluZyhcImRldmljZUpzb25cIilcbiAgICB9KS50aGVuKFxuICAgICAgZnVuY3Rpb24ocmVzcG9uc2UpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2Uuc3RhdHVzQ29kZSk7XG4gICAgICB9LFxuICAgICAgZnVuY3Rpb24oZSkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkVycm9yIG9jY3VycmVkIFwiICsgZSk7XG4gICAgICB9XG4gICAgKTtcbiAgfVxufVxuIl19